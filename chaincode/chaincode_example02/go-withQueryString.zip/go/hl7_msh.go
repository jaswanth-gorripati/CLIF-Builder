package main

//Hl7Msh  Hl7 format for msh key"
type Hl7Msh struct {
	Class                                                 string `json:"$class"`
	Doctype                                               string `json:"doctype,omitemit"`
	MSHKEY                                                string `json:"MSHKEY"`
	SendingApplicationNamespaceID                         string `json:"SendingApplicationNamespaceID,omitempty"`
	SendingApplicationUniversalID                         string `json:"SendingApplicationUniversalID,omitempty"`
	SendingApplicationUniversalIDType                     string `json:"SendingApplicationUniversalIDType,omitempty"`
	SendingFacilityNamespaceID                            string `json:"SendingFacilityNamespaceID,omitempty"`
	SendingFacilityUniversalID                            string `json:"SendingFacilityUniversalID,omitempty"`
	SendingFacilityUniversalIDType                        string `json:"SendingFacilityUniversalIDType,omitempty"`
	ReceivingApplicationNamespaceID                       string `json:"ReceivingApplicationNamespaceID,omitempty"`
	ReceivingApplicationUniversalID                       string `json:"ReceivingApplicationUniversalID ,omitempty"`
	ReceivingApplicationUniversalIDType                   string `json:"ReceivingApplicationUniversalIDType,omitempty"`
	ReceivingFacilityNamespaceID                          string `json:"ReceivingFacilityNamespaceID,omitempty"`
	ReceivingFacilityUniversalID                          string `json:"ReceivingFacilityUniversalID,omitempty"`
	ReceivingFacilityUniversalIDType                      string `json:"ReceivingFacilityUniversalIDType,omitempty"`
	MessageTime                                           string `json:"MessageTime,omitempty"`
	MessageYear                                           string `json:"MessageYear,omitempty"`
	MessageMonth                                          string `json:"MessageMonth,omitempty"`
	MessageDay                                            string `json:"MessageDay,omitempty"`
	MessageHours                                          string `json:"MessageHours,omitempty"`
	MessageMinutes                                        string `json:"MessageMinutes,omitempty"`
	MessageSeconds                                        string `json:"MessageSeconds,omitempty"`
	MessageMills                                          string `json:"MessageMills,omitempty"`
	MessageGmtOffset                                      string `json:"MessageGmtOffset,omitempty"`
	Precision                                             string `json:"Precision,omitempty"`
	Security                                              string `json:"Security,omitempty"`
	MessageType                                           string `json:"MessageType,omitempty"`
	TriggerEvent                                          string `json:"TriggerEvent,omitempty"`
	MessageStructure                                      string `json:"MessageStructure,omitempty"`
	MessageControlID                                      string `json:"MessageControlID,omitempty"`
	ProcessingID                                          string `json:"ProcessingID,omitempty"`
	ProcessingMode                                        string `json:"ProcessingMode,omitempty"`
	VersionID                                             string `json:"VersionID,omitempty"`
	VersionIdentifier                                     string `json:"VersionIdentifier,omitempty"`
	VersionText                                           string `json:"VersionText,omitempty"`
	VersionNameOfCodingSystem                             string `json:"VersionNameOfCodingSystem,omitempty"`
	VersionAlternateIdentifier                            string `json:"VersionAlternateIdentifier,omitempty"`
	VersionAlternateText                                  string `json:"VersionAlternateText,omitempty"`
	VersionNameOfAlternateCodingSystem                    string `json:"VersionNameOfAlternateCodingSystem,omitempty"`
	InternationalVersionIIdentifier                       string `json:"InternationalVersionIIdentifier,omitempty"`
	InternationalVersionIText                             string `json:"InternationalVersionIText,omitempty"`
	InternationalVersionINameOfCodingSystem               string `json:"InternationalVersionINameOfCodingSystem,omitempty"`
	InternationalVersionIAlternateIdentifier              string `json:"InternationalVersionIAlternateIdentifier,omitempty"`
	InternationalVersionIAlternateText                    string `json:"InternationalVersionIAlternateText,omitempty"`
	InternationalVersionINameOfAlternateCodingSystem      string `json:"InternationalVersionINameOfAlternateCodingSystem,omitempty"`
	SequenceNumber                                        string `json:"SequenceNumber,omitempty"`
	ContinuationPointer                                   string `json:"ContinuationPointer,omitempty"`
	AcceptAcknowledgementType                             string `json:"AcceptAcknowledgementType,omitempty"`
	ApplicationAcknowledgementType                        string `json:"ApplicationAcknowledgementType,omitempty"`
	CountryCode                                           string `json:"CountryCode,omitempty"`
	PrincipalLanguageOfMessageIdentifier                  string `json:"PrincipalLanguageOfMessageIdentifier,omitempty"`
	PrincipalLanguageOfMessageText                        string `json:"PrincipalLanguageOfMessageText,omitempty"`
	PrincipalLanguageOfMessageNameOfCodingSystem          string `json:"PrincipalLanguageOfMessageNameOfCodingSystem,omitempty"`
	PrincipalLanguageOfMessageAlternateIdentifier         string `json:"PrincipalLanguageOfMessageAlternateIdentifier,omitempty"`
	PrincipalLanguageOfMessageAlternateText               string `json:"PrincipalLanguageOfMessageAlternateText,omitempty"`
	PrincipalLanguageOfMessageNameOfAlternateCodingSystem string `json:"PrincipalLanguageOfMessageNameOfAlternateCodingSystem,omitempty"`
	AlternateCharacterSetHandlingScheme                   string `json:"AlternateCharacterSetHandlingScheme,omitempty"`
}

// MSHFiles : Msh files list
type MSHFiles struct {
	Doctype     string `json:"doctype,omitemit"`
	MSHKEY      string `json:"MSHKEY,omitempty"`
	PIDhashFile string `json:"PIDhashFile,omitempty"`
	OBRhashFile string `json:"OBRhashFile,omitempty"`
	OBXhashFile string `json:"OBXhashFile,omitempty"`
	PV1hashFile string `json:"PV1hashFile,omitempty"`
	ORChashFile string `json:"ORChashFile,omitempty"`
	//hashFile  string `json:"PIDhashFile,omitempty"`
}
